const config={
    host:"http://localhost:5000"
};
export default config;